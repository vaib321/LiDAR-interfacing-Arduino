# LIDAR-Light-Detection-and-Ranging-Sensor-Interfacing-with-Arduino
The Light Imaging Detection and Ranging (LIDAR) is a method for measuring distances (ranging) by illuminating the target with laser light and measuring the reflection with a sensor. The LIDAR Sensor escalates the entire mechanism with great efficiency which is notified with process and main activation codes.
